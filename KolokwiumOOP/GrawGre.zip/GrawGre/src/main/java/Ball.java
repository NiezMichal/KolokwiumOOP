import java.awt.*;
import java.awt.geom.Point2D;

public class Ball extends GraphicsItem {

    private Point2D moveVector;
    private double velocity;

    public Ball() {
        this.width = 0.03;
        this.height = 0.03;
        double angle = Math.toRadians(45);
        this.moveVector = new Point2D.Double(Math.cos(angle), -Math.sin(angle));
        this.velocity = 0.4;
    }

    public void setPosition(Point2D point) {
        this.x = point.getX() - (this.width / 2);
        this.y = point.getY() - (this.height / 2);
    }

    public void updatePosition(double deltaTime) {
        this.x += moveVector.getX() * velocity * deltaTime;
        this.y += moveVector.getY() * velocity * deltaTime;
    }

    public void bounceHorizontally() {
        this.moveVector = new Point2D.Double(moveVector.getX(), -moveVector.getY());
    }

    public void bounceVertically() {
        this.moveVector = new Point2D.Double(-moveVector.getX(), moveVector.getY());
    }


    public void bounceFromPaddle(double hitFactor) {
        double baseAngle = 90.0;
        double maxAngleInfluence = 60.0;

        double angleInDegrees = baseAngle - (hitFactor * maxAngleInfluence);
        double angleInRadians = Math.toRadians(angleInDegrees);

        this.moveVector = new Point2D.Double(Math.cos(angleInRadians), -Math.sin(angleInRadians));
    }

    public Point2D getMoveVector() { return moveVector; }
    public Point2D getTopPoint() { return new Point2D.Double(x + (width / 2), y); }
    public Point2D getBottomPoint() { return new Point2D.Double(x + (width / 2), y + height); }
    public Point2D getLeftPoint() { return new Point2D.Double(x, y + (height / 2)); }
    public Point2D getRightPoint() { return new Point2D.Double(x + width, y + (height / 2)); }

    @Override
    public void draw(Graphics2D g2d) {
        int screenX = (int) (x * canvasWidth);
        int screenY = (int) (y * canvasHeight);
        int screenWidth = (int) (width * canvasWidth);
        int screenHeight = (int) (height * canvasHeight);

        g2d.setColor(Color.WHITE);
        g2d.fillOval(screenX, screenY, screenWidth, screenHeight);
    }
}