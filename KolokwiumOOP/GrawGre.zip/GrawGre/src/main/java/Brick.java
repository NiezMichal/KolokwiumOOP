import java.awt.*;
import java.awt.geom.Point2D;

public class Brick extends GraphicsItem {


    public enum CrushType {
        NoCrush,
        HorizontalCrush,
        VerticalCrush
    }

    private static int gridRows;
    private static int gridCols;
    private Color color;

    public static void setGridSize(int rows, int cols) {
        gridRows = rows;
        gridCols = cols;
    }

    public Brick(int gridX, int gridY, Color color) {
        this.color = color;
        this.width = 1.0 / gridCols;
        this.height = 1.0 / gridRows;
        this.x = gridX * this.width;
        this.y = gridY * this.height;
    }

    public CrushType checkCrush(Point2D top, Point2D bottom, Point2D left, Point2D right) {

        if (isPointInside(bottom) || isPointInside(top)) {
            return CrushType.HorizontalCrush;
        }


        if (isPointInside(right) || isPointInside(left)) {
            return CrushType.VerticalCrush;
        }

        return CrushType.NoCrush;
    }


    private boolean isPointInside(Point2D p) {
        return p.getX() >= this.x && p.getX() <= this.x + this.width &&
                p.getY() >= this.y && p.getY() <= this.y + this.height;
    }

    @Override
    public void draw(Graphics2D g2d) {
        int screenX = (int) (x * canvasWidth);
        int screenY = (int) (y * canvasHeight);
        int screenWidth = (int) (width * canvasWidth);
        int screenHeight = (int) (height * canvasHeight);

        g2d.setColor(color);
        g2d.fill3DRect(screenX, screenY, screenWidth, screenHeight, true);
    }
}