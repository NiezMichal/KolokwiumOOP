import javax.swing.*;
import java.awt.*;

public class GameCanvas extends JPanel {
    public static final int WIDTH  = 640;
    public static final int HEIGHT = 800;

    private Graphics2D graphicsContext;

    public GameCanvas() {
        setPreferredSize(new Dimension(WIDTH, HEIGHT));
        setBackground(Color.BLACK);
        setFocusable(true);
        GraphicsItem.setSize(HEIGHT, WIDTH);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        this.graphicsContext = (Graphics2D) g;
        draw();
    }

    public void draw() {
        if (graphicsContext != null) {
            graphicsContext.setColor(Color.BLACK);
            graphicsContext.fillRect(0, 0, getWidth(), getHeight());
        }
    }
}