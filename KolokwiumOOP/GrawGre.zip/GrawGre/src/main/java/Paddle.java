import java.awt.*;

public class Paddle extends GraphicsItem {

    public Paddle() {
        this.width = 0.2;
        this.height = 0.03;
        this.x = 0.5 - (this.width / 2);
        this.y = 0.9;
    }

    @Override
    public void draw(Graphics2D g2d) {
        int screenX = (int) (x * canvasWidth);
        int screenY = (int) (y * canvasHeight);
        int screenWidth = (int) (width * canvasWidth);
        int screenHeight = (int) (height * canvasHeight);

        g2d.setColor(Color.GREEN);
        g2d.fillRect(screenX, screenY, screenWidth, screenHeight);
    }

    public void setPositionByMouse(int mouseX) {
        if (canvasWidth > 0) {

            double normalizedMouseX = (double) mouseX / canvasWidth;
            this.x = normalizedMouseX - (this.width / 2);
            if (this.x < 0) this.x = 0;
            if (this.x + this.width > 1) this.x = 1 - this.width;
        }
    }
}