import javax.swing.*;
import java.awt.*;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.List;

public class GamePanel extends JPanel {
    public static final int WIDTH  = 640;
    public static final int HEIGHT = 800;

    private Paddle paddle;
    private Ball ball;
    private List<Brick> bricks = new ArrayList<>(); // Lista na cegły

    private boolean gameStarted = false;
    private Timer gameLoopTimer;
    private long lastTime;

    public GamePanel() {
        setPreferredSize(new Dimension(WIDTH, HEIGHT));
        setBackground(Color.BLACK);
        setFocusable(true);

        GraphicsItem.setSize(HEIGHT, WIDTH);

        paddle = new Paddle();
        ball = new Ball();

        loadLevel();

        updateBallOnPaddle();

        addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent e) {
                paddle.setPositionByMouse(e.getX());
                if (!gameStarted) {
                    updateBallOnPaddle();
                }
                repaint();
            }
        });

        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (!gameStarted) {
                    gameStarted = true;
                    startGameLoop();
                }
            }
        });
    }

    private void loadLevel() {
        int rows = 20;
        int cols = 10;

        Brick.setGridSize(rows, cols);

        Color[] rowColors = {
                Color.RED,          // wiersz 2
                Color.ORANGE,       // wiersz 3
                Color.YELLOW,       // wiersz 4
                Color.GREEN,        // wiersz 5
                Color.BLUE,         // wiersz 6
                Color.MAGENTA       // wiersz 7
        };

        bricks.clear();

        for (int r = 2; r <= 7; r++) {
            Color currentColor = rowColors[r - 2];

            for (int c = 0; c < cols; c++) {
                bricks.add(new Brick(c, r, currentColor));
            }
        }
    }

    private void updateBallOnPaddle() {
        double ballX = paddle.getX() + (paddle.getWidth() / 2);
        double ballY = paddle.getY() - 0.02;
        ball.setPosition(new Point2D.Double(ballX, ballY));
    }

    private boolean shouldBallBounceVertically() {
        return ball.getX() <= 0 || (ball.getX() + ball.getWidth() >= 1.0);
    }

    private boolean shouldBallBounceHorizontally() {
        return ball.getY() <= 0;
    }

    private boolean shouldBallBounceFromPaddle() {
        boolean intersects = ball.getX() < paddle.getX() + paddle.getWidth() &&
                ball.getX() + ball.getWidth() > paddle.getX() &&
                ball.getY() < paddle.getY() + paddle.getHeight() &&
                ball.getY() + ball.getHeight() > paddle.getY();

        return intersects && ball.getMoveVector().getY() > 0;
    }

    private void startGameLoop() {
        lastTime = System.nanoTime();

        gameLoopTimer = new Timer(16, e -> {
            long currentTime = System.nanoTime();
            double deltaTime = (currentTime - lastTime) / 1_000_000_000.0;
            lastTime = currentTime;

            if (gameStarted) {
                ball.updatePosition(deltaTime);

                if (shouldBallBounceVertically()) {
                    ball.bounceVertically();
                }
                if (shouldBallBounceHorizontally()) {
                    ball.bounceHorizontally();
                }

                if (shouldBallBounceFromPaddle()) {
                    double ballCenterX = ball.getX() + (ball.getWidth() / 2);
                    double paddleCenterX = paddle.getX() + (paddle.getWidth() / 2);

                    double deltaX = ballCenterX - paddleCenterX;

                    double halfPaddleWidth = paddle.getWidth() / 2;

                    double hitFactor = deltaX / halfPaddleWidth;

                    if (hitFactor < -1.0) hitFactor = -1.0;
                    if (hitFactor > 1.0) hitFactor = 1.0;

                    ball.bounceFromPaddle(hitFactor);
                }
                for (int i = bricks.size() - 1; i >= 0; i--) {
                    Brick brick = bricks.get(i);

                    Brick.CrushType crush = brick.checkCrush(
                            ball.getTopPoint(),
                            ball.getBottomPoint(),
                            ball.getLeftPoint(),
                            ball.getRightPoint()
                    );

                    if (crush != Brick.CrushType.NoCrush) {
                        if (crush == Brick.CrushType.HorizontalCrush) {
                            ball.bounceHorizontally();
                        } else if (crush == Brick.CrushType.VerticalCrush) {
                            ball.bounceVertically();
                        }

                        bricks.remove(i);
                        break;
                    }
                }

                if (ball.getY() > 1.0) {
                    gameStarted = false;
                    loadLevel();
                    updateBallOnPaddle();
                    gameLoopTimer.stop();
                }
            }

            repaint();
        });

        gameLoopTimer.start();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;


        if (paddle != null) {
            paddle.draw(g2d);
        }

        for (Brick brick : bricks) {
            brick.draw(g2d);
        }

        if (ball != null) {
            ball.draw(g2d);
        }
    }
}